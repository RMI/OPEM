from opem import main
import cProfile
import re

cProfile.run('main()')
